﻿If you'd like to add your own sprites I encourage you to use EDG32 color palette by ENDESGA (Twitter: @ENDESGA) which is included in this pack.


Thank you for buying "Tiny, Tiny Heroes - Armies" and I wish you best of luck in your personal and commercial projects,


Kacper "ThKaspar" Woźniak


You can contact me at:
	E-Mail: kac.wozniak@gmail.com

	Twitter: @ThKasparrr
 | twitter.com/ThKasparrr
	DeviantArt: ThKaspar
 | deviantart.com/thkaspar